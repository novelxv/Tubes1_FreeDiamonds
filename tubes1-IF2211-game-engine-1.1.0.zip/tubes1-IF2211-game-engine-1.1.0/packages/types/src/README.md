| Folder       | Description                                       |
| ------------ | ------------------------------------------------- |
| `admin2`     | Types that are used for data storage              |
| `auth`       | Types belonging to authentication project         |
| `enums`      | Enumerations and constants used in the project    |
| `interfaces` | Interfaces used by classes & mocks in the project |
| `types`      | Types used around the project                     |
