export interface ITeamDto {
  id: string;
  name: string;
  abbreviation: string;
  logotypeUrl: string;
}
