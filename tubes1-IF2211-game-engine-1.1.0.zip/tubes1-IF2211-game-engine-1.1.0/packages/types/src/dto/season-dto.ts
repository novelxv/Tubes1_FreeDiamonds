export interface ISeasonDto {
  id: string;
  name: string;
  startDate: Date;
  endDate: Date;
}
