export interface IHighscoreDto {
  botName: string;
  score: number;
  seasonId: string;
  team: string;
  teamLogotype: string;
}
