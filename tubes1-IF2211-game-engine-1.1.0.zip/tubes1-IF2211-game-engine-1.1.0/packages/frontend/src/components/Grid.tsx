import { FC, memo } from 'react';

export const Grid: FC = memo(() => {
  return <div>Grid</div>;
});
Grid.displayName = 'Grid';
