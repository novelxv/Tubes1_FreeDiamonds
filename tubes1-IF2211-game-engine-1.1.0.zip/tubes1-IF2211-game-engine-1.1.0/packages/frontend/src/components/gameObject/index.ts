export * from './BaseObject';
export * from './BotObject';
export * from './DiamondButtonObject';
export * from './DiamondObject';
export * from './TeleportObject';
