-- AlterTable
ALTER TABLE "BoardConfig" ADD COLUMN     "dummyBots" SMALLINT NOT NULL DEFAULT 0;
