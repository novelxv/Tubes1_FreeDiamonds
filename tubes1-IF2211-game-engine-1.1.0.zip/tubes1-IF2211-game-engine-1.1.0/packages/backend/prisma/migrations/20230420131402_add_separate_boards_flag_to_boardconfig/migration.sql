-- AlterTable
ALTER TABLE "BoardConfig" ADD COLUMN     "separateBoards" BOOLEAN NOT NULL DEFAULT false;
