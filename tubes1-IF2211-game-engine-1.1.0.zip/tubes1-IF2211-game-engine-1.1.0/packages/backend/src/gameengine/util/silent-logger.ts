export class SilentLogger {
  info() {}
  debug() {}
  warn() {}
  error() {}
  critical() {}
  log() {}
  trace() {}
  verbose() {}
}
