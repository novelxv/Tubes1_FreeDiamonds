export enum BotsErrors {
  InvalidEmail = "InvalidEmail",
  AlreadyExists = "BotAlreadyExists",
  NotFound = "BotNotFound",
}
