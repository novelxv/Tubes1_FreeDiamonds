export interface IBot {
  id?: string;
  name?: string;
  email?: string;
}
